const fs = require('fs');
let content = fs.readFileSync('src/components/QueueTickets.tsx', 'utf-8');

// Add dateFilter state
content = content.replace(
  'const [serviceTypeFilter, setServiceTypeFilter] = useState<string>("All");',
  'const [serviceTypeFilter, setServiceTypeFilter] = useState<string>("All");\n  const [dateFilter, setDateFilter] = useState<string>("All");'
);

// Update filtering logic
content = content.replace(
  '      (serviceTypeFilter === "All" || t.serviceType === serviceTypeFilter) &&',
  `      (serviceTypeFilter === "All" || t.serviceType === serviceTypeFilter) &&
      (dateFilter === "All" || (
        dateFilter === "Today" ? (t.createdAt >= new Date(new Date().setHours(0,0,0,0))) :
        dateFilter === "Yesterday" ? (t.createdAt >= new Date(new Date().setDate(new Date().getDate() - 1)) && t.createdAt < new Date(new Date().setHours(0,0,0,0))) :
        dateFilter === "This Week" ? (t.createdAt >= new Date(new Date().setDate(new Date().getDate() - 7))) :
        dateFilter === "Last 30 Days" ? (t.createdAt >= new Date(new Date().setDate(new Date().getDate() - 30))) : true
      )) &&`
);

// Update UI logic for Date Filter
content = content.replace(
  '{/* Mock date filters - in a real app these would update state and filter the tickets array */}',
  ''
);

content = content.replace(
  '<button onClick={() => setActiveFilterDropdown(null)} className="w-full text-left py-1 text-sm text-slate-700 hover:text-brand-cyan">Today</button>',
  '<button onClick={() => { setDateFilter("All"); setActiveFilterDropdown(null); }} className="w-full text-left py-1 text-sm text-slate-700 hover:text-brand-cyan">All Time</button>\n                <button onClick={() => { setDateFilter("Today"); setActiveFilterDropdown(null); }} className="w-full text-left py-1 text-sm text-slate-700 hover:text-brand-cyan">Today</button>'
);

content = content.replace(
  '<button onClick={() => setActiveFilterDropdown(null)} className="w-full text-left py-1 text-sm text-slate-700 hover:text-brand-cyan">Yesterday</button>',
  '<button onClick={() => { setDateFilter("Yesterday"); setActiveFilterDropdown(null); }} className="w-full text-left py-1 text-sm text-slate-700 hover:text-brand-cyan">Yesterday</button>'
);

content = content.replace(
  '<button onClick={() => setActiveFilterDropdown(null)} className="w-full text-left py-1 text-sm text-slate-700 hover:text-brand-cyan">This Week</button>',
  '<button onClick={() => { setDateFilter("This Week"); setActiveFilterDropdown(null); }} className="w-full text-left py-1 text-sm text-slate-700 hover:text-brand-cyan">This Week</button>'
);

content = content.replace(
  '<button onClick={() => setActiveFilterDropdown(null)} className="w-full text-left py-1 text-sm text-slate-700 hover:text-brand-cyan">Last 30 Days</button>',
  '<button onClick={() => { setDateFilter("Last 30 Days"); setActiveFilterDropdown(null); }} className="w-full text-left py-1 text-sm text-slate-700 hover:text-brand-cyan">Last 30 Days</button>'
);

// Show active date filter in button
content = content.replace(
  '<Calendar className="w-3.5 h-3.5 text-slate-400" /> Date Range <ChevronDown className="w-3.5 h-3.5 text-slate-400" />',
  '<Calendar className="w-3.5 h-3.5 text-slate-400" /> {dateFilter === "All" ? "Date Range" : dateFilter} <ChevronDown className="w-3.5 h-3.5 text-slate-400" />'
);

fs.writeFileSync('src/components/QueueTickets.tsx', content);
