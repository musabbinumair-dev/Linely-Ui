const fs = require('fs');
let content = fs.readFileSync('src/components/AdminDashboard.tsx', 'utf-8');

// Remove from Dashboard
content = content.replace('{ id: "queue-tickets", label: "Queue Tickets" }', '');
content = content.replace('{ id: "queue-tickets", label: "Queue Tickets" },', '');
content = content.replace(',\n                          \n                        ]', '\n                        ]');
content = content.replace(',\n                            \n                          ]', '\n                          ]');

// Also fix commas
content = content.replace('{ id: "daily-summary", label: "Daily Summary Tracker" },\n                        ]', '{ id: "daily-summary", label: "Daily Summary Tracker" }\n                        ]');
content = content.replace('{ id: "daily-summary", label: "Daily Summary Tracker" },\n                          ]', '{ id: "daily-summary", label: "Daily Summary Tracker" }\n                          ]');

// Add to Tokens
const tokenTarget1 = `                        subItems: [
                          { id: "queue-history", label: "Token Generation Logs" }
                        ]`;
const tokenReplacement1 = `                        subItems: [
                          { id: "queue-tickets", label: "Queue Tickets" },
                          { id: "queue-history", label: "Token Generation Logs" }
                        ]`;
                        
const tokenTarget2 = `                  subItems: [
                    { id: "queue-history", label: "Token Generation Logs" }
                  ]`;
const tokenReplacement2 = `                  subItems: [
                    { id: "queue-tickets", label: "Queue Tickets" },
                    { id: "queue-history", label: "Token Generation Logs" }
                  ]`;

content = content.replace(tokenTarget1, tokenReplacement1);
content = content.replace(tokenTarget2, tokenReplacement2);

fs.writeFileSync('src/components/AdminDashboard.tsx', content);
console.log("Patched!");
