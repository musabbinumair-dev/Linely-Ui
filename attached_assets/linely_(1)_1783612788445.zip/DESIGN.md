# Linely — High-Fidelity Queue Management SaaS
## Comprehensive System & Design Architecture Specification

This document provides a highly detailed specification of **Linely's** product design, application architecture, component hierarchy, visual identity, and technical implementation details.

---

## 1. Executive Summary & Product Vision

**Linely** is a modern, high-fidelity Queue Management Software-as-a-Service (SaaS) designed to bridge physical wait environments with digital-first operations. While traditional queue management tools are either visually dated or functionally siloed, Linely integrates an elegant, conversion-focused **Landing Page**, a real-time **Operator Console** for frontline counter staff, and an executive **Admin Dashboard** containing performance metrics, stress-simulation tools, and white-label branding controls.

### Core Value Propositions
*   **Frontline Simplicity:** Eliminates chaotic check-in sheets with a simplified, tactile ticket control system.
*   **Operational Intelligence:** Empowers branch managers to simulate queue dynamics under variable loads (such as lunch hour spikes) to optimize counter staffing.
*   **Brand Customization:** Enables immediate white-labeling of customer ticket headers, colors, and labels from a single admin viewport.
*   **Sensory Reinforcement:** Employs low-latency Web Audio API synthesizers to alert operators and customers without relying on intrusive, abrasive hardware chimes.

---

## 2. Visual & Aesthetic Identity

Linely’s user interface focuses on **intentional pairings** of premium typography, micro-animations, and balanced negative space to cultivate a sense of order, trust, and calm.

### 🎨 Color System & Palette
The application uses a distinctive, high-contrast, editorial color palette tailored for legibility under varying office and counter lighting conditions:

| Color Name | Hex Code | Visual Role | Emotional Vibe |
| :--- | :--- | :--- | :--- |
| **Brand Navy** | `#0D1A5E` | Dominant structural headers, primary text, and dark backdrops. | Trusted, premium, architectural. |
| **Brand Deep Navy**| `#08103F` | Deep page footprints, active console cards, and structural margins. | Safe, dense, institutional. |
| **Brand Cyan** | `#00C3E3` | Accents, active token counts, highlights, and primary active buttons. | High-tech, active, clean, energetic. |
| **Brand Cream** | `#FCF9F2` | Soothing card backgrounds, layout frames, and ambient highlights. | Sophisticated, organic, calm. |
| **Slate / Off-White** | `#F8FAFC` | Core landing page section backgrounds and card gutters. | Swiss-style utility, clean spacing. |

### ✍️ Typography Strategy
Typography is meticulously structured to establish immediate visual rhythm and information hierarchy:

1.  **Primary Sans-Serif (`Inter` / `Rethink Sans`):** Applied to general UI navigation, form labels, and interactive cards for extreme legibility.
2.  **Display Sans-Serif (`Outfit` / `Space Grotesk`):** Applied to bold landing page headings and display numbers (e.g., ticket values) to convey precision and modernization.
3.  **Monospace (`JetBrains Mono` / `SF Mono`):** Applied exclusively to system telemetry logs, audit trails, timing indices, and SLA statistics to underscore technical accuracy.

### 🔄 Motion & Micro-interactions
Rather than static transitions, Linely leverages custom spring physics to guide cognitive focus:
*   **Enter/Exit Transitions:** Key layouts (landing page vs. console vs. admin) employ a `0.35s ease-in-out` fade and translate animation powered by Framer Motion.
*   **Spring-Elastic Modals:** The `LoginSelectionModal` enters via a custom spring (`damping: 25`, `stiffness: 350`) for a responsive, material-like slide.
*   **Interactive Hover Effects:** Every button and card utilizes a subtle scale-up (`scale-102`), vertical offset (`y: -2`), and shadow shift to indicate interactability.

---

## 3. High-Fidelity Architecture & Viewports

Linely operates as a Single-Page Application (SPA) structured around three primary visual environments, seamlessly navigated via state-driven views and gated by a centralized entry portal.

```
                      ┌─────────────────────────────────┐
                      │      Landing Page View          │
                      │   (Marketing, Pricing, Copy)     │
                      └────────────────┬────────────────┘
                                       │
                                       ▼ (Sign In / Try Free)
                      ┌─────────────────────────────────┐
                      │     LoginSelectionModal         │
                      │  (Gated Portal Route Selector)  │
                      └──────────┬─────────────┬────────┘
                                 │             │
              ┌──────────────────┘             └──────────────────┐
              ▼                                                   ▼
┌───────────────────────────┐                       ┌───────────────────────────┐
│   Operator Console View   │                       │   Admin Dashboard View    │
│  - Counter Management     │                       │  - Queue Stress Simulator │
│  - Real-time Stream       │                       │  - Live Performance SLAs  │
│  - Sound Synthesis        │                       │  - White-Label Designer   │
│  - Simulated QR Scanner   │                       │  - Immutable Audit Trails │
└───────────────────────────┘                       └───────────────────────────┘
```

### A. The Landing Page Experience
A fully-realized marketing and informational portal demonstrating the platform's utility:
*   **Sticky Dynamic Header (`Navbar`):** Transparent on initial load, transitioning to a dense, blurred off-white navigation bar once scrolled past the fold.
*   **Interactive Stacking Cards:** An immersive scroll-linked card deck where cards physically stack and anchor themselves at the top of the screen as the user scrolls, visualizing the concept of "order out of chaos."
*   **Interactive Operator Mockup:** Inline high-fidelity dashboard views inside "Why Linely" allowing users to visually grasp the product before executing a login.

### B. The Gated Portal Gateway (`LoginSelectionModal`)
A streamlined, lightweight, and responsive portal designed to guide users into their active workspace:
*   **Compact Optimization:** Formatted with custom, space-efficient bento structures to remain fully responsive on mobile viewports and small screens.
*   **Pathway Differentiation:**
    1.  *Operator Route:* Boots the real-time front-facing counter panel.
    2.  *Admin Route:* Boots the global management system, performance analytics suite, and live queue stress simulator.

### C. The Operator Console (`OperatorConsole`)
The frontline workhorse designed to handle heavy customer flow at physical service counters:
*   **Tactile Controls:** Large, high-visibility buttons to "Call Next Customer", "Mark Complete", "Flag as Delayed", or "Transfer to Counter."
*   **Auditory Feedback:** A fully-programmable sound synthesizer that generates a clear, pure dual-frequency tone (523.25Hz and 659.25Hz) using the browser's Web Audio API, avoiding raw sound file requests or assets.
*   **Simulated Scanner:** Uses a camera-scanning framework equipped with a highly-polished interactive simulation panel. If local camera hardware is not available, it switches to a scanning simulation module to allow mock testing.

### D. The Admin Control Center (`AdminDashboard`)
A comprehensive management viewport split into four interactive operational sections:
1.  **Executive Analytics:** Track branch-level service speeds, counter distributions, and overall SLA compliance scores.
2.  **Live Queue Stress Simulator:** An interactive engine allowing administrators to modify:
    *   *Arrival Rate* (customers/hour)
    *   *Service Speed* (minutes/customer)
    *   *Counter Staffing* (active operators)
    *   Once triggered, a mathematical state engine processes the values and prints a live-scrolling simulation sequence, calculating real-time wait times and SLA breaches.
3.  **White-Label Customization:** Modify branding titles, counter labels, color accents, and active messages. Changes are reflected instantly.
4.  **Trace Audit Logs:** A persistent, scrollable ledger documenting all simulator milestones, branding adjustments, and console sessions.

---

## 4. Component Directory & Blueprint

The codebase is strictly modularized to maintain performance, type-safety, and readability:

### `/src` (Root)
*   `App.tsx`: Central coordinator managing active layout views, transition wrapper animations, and modal state triggers.
*   `types.ts`: Holds shared type safety definitions, including types for active queue clients, counters, simulation parameters, and audit logs.
*   `index.css`: Imports custom Google Fonts and defines the root Tailwind theme color mapping.

### `/src/components` (UI Modules)
*   `Navbar.tsx`: Implements the sticky scrolling header, mobile responsive hamburger menu, and triggers the `LoginSelectionModal`.
*   `Hero.tsx`: Large, atmospheric introduction block utilizing dark cosmic colors paired with high-impact call-to-actions.
*   `TrustedBy.tsx`: Elegant customer proof layout.
*   `Solution.tsx`: A bento-grid feature breakdown.
*   `WhyLinely.tsx`: Displays interactive high-fidelity preview frames of the dashboard consoles.
*   `Industries.tsx`: Custom tabbed view showing sector-specific deployments (Banking, Retail, Healthcare, Government).
*   `Features.tsx`: Focuses on technical assets like automated tokening and barcode compatibility.
*   `WhyChoose.tsx`: Direct utility-first marketing panel.
*   `StackingCards.tsx`: CSS/Framer Motion-powered overlay structure that visually stacks cards vertically during page scroll.
*   `Pricing.tsx`: Transparent tier options.
*   `LoginSelectionModal.tsx`: The optimized workspace selector modal, configured with escape-key triggers and viewport body scroll lockouts.
*   `OperatorConsole.tsx`: The comprehensive agent workspace featuring queue streams, audio chime controllers, and camera simulations.
*   `AdminDashboard.tsx`: Executive management center featuring the queue stress simulator, branding toolkits, and audit ledgers.
*   `Footer.tsx`: Modern, high-density structured footer links.

---

## 5. Technical Highlights & Custom Implementations

### 🔊 High-Fidelity Audio Synthesis
To avoid relying on external sound assets which can fail to load or get blocked, Linely utilizes the native **Web Audio API** to compile and play a warm, custom chime when calling a customer:

```typescript
export function playChime() {
  const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
  
  // Dual oscillators for a rich, warm harmonious chime (C5 + E5 chord)
  const osc1 = audioCtx.createOscillator();
  const osc2 = audioCtx.createOscillator();
  const gainNode = audioCtx.createGain();

  osc1.type = "sine";
  osc1.frequency.setValueAtTime(523.25, audioCtx.currentTime); // C5

  osc2.type = "sine";
  osc2.frequency.setValueAtTime(659.25, audioCtx.currentTime); // E5

  // Envelope generation to create a smooth fade-out
  gainNode.gain.setValueAtTime(0.15, audioCtx.currentTime);
  gainNode.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 1.2);

  osc1.connect(gainNode);
  osc2.connect(gainNode);
  gainNode.connect(audioCtx.destination);

  osc1.start();
  osc2.start();
  osc1.stop(audioCtx.currentTime + 1.2);
  osc2.stop(audioCtx.currentTime + 1.2);
}
```

### 📉 Live Queue Stress Simulator Engine
Inside the **Admin Control Center**, the queue simulation runs a virtual interval loop that models an active queue. It calculates the theoretical waiting line length and average service times based on Poisson-like customer arrival rates and Exponential service speeds:

$$\lambda = \text{Arrival Rate}, \quad \mu = \text{Service Rate}$$

Each simulation tick (representing simulated time intervals) calculates:
*   Incoming customers based on the configured $\lambda$.
*   Processed customers based on active counters multiplied by $\mu$.
*   SLA breach probabilities when the simulated wait time exceeds 15 minutes.

---

## 6. Security, Performance & Scalability

1.  **State Isolation:** Component states are isolated to minimize global re-renders. Large collections (like audit logs) are indexed and updated via structural immutability patterns (`[newItem, ...prevLogs]`).
2.  **Hardware Fallbacks:** The camera-scanning module handles permissions safely. If camera permissions are blocked, denied, or unavailable in local iframe sandboxes, the system automatically redirects to an interactive high-fidelity simulation without interrupting the user workflow.
3.  **Strict Responsive Control:** Absolute dimensions are avoided. Grid systems employ fluid column sizing (`grid-cols-1 md:grid-cols-2 lg:grid-cols-4`) to support screens as small as 320px and as wide as 1920px.

---
*Prepared by the Linely Engineering & Design team. All rights reserved.*
