const fs = require('fs');
let content = fs.readFileSync('src/components/QueueTickets.tsx', 'utf-8');

const target = `          {/* Service Type Filter */}
          <div className="hidden lg:block relative filter-dropdown-container">
            <button onClick={() => setActiveFilterDropdown(activeFilterDropdown === 'service' ? null : 'service')} className="flex items-center gap-1.5 px-3 py-2.5 bg-white border border-slate-200 rounded-xl text-[13px] font-bold text-slate-700 hover:bg-slate-50 transition-colors shadow-sm">
              Service: {serviceTypeFilter} <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
            </button>
            {activeFilterDropdown === 'service' && (
              <div className="absolute top-full left-0 mt-1 w-48 bg-white border border-slate-200 rounded-xl shadow-lg z-20 py-1">
                {["All", ...serviceTypes].map(s => (
                  <button key={s} onClick={() => { setServiceTypeFilter(s); setActiveFilterDropdown(null); }} className="w-full text-left px-4 py-2 text-sm text-slate-700 hover:bg-slate-50">
                    {s}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>`;

const replacement = `          {/* Service Type Filter */}
          <div className="hidden lg:block relative filter-dropdown-container">
            <button onClick={() => setActiveFilterDropdown(activeFilterDropdown === 'service' ? null : 'service')} className="flex items-center gap-1.5 px-3 py-2.5 bg-white border border-slate-200 rounded-xl text-[13px] font-bold text-slate-700 hover:bg-slate-50 transition-colors shadow-sm">
              Service: {serviceTypeFilter} <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
            </button>
            {activeFilterDropdown === 'service' && (
              <div className="absolute top-full left-0 mt-1 w-48 bg-white border border-slate-200 rounded-xl shadow-lg z-20 py-1">
                {["All", ...serviceTypes].map(s => (
                  <button key={s} onClick={() => { setServiceTypeFilter(s); setActiveFilterDropdown(null); }} className="w-full text-left px-4 py-2 text-sm text-slate-700 hover:bg-slate-50">
                    {s}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Date Range Filter */}
          <div className="hidden xl:block relative filter-dropdown-container">
            <button onClick={() => setActiveFilterDropdown(activeFilterDropdown === 'date' ? null : 'date')} className="flex items-center gap-1.5 px-3 py-2.5 bg-white border border-slate-200 rounded-xl text-[13px] font-bold text-slate-700 hover:bg-slate-50 transition-colors shadow-sm">
              <Calendar className="w-3.5 h-3.5 text-slate-400" /> Date Range <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
            </button>
            {activeFilterDropdown === 'date' && (
              <div className="absolute top-full left-0 mt-1 w-48 bg-white border border-slate-200 rounded-xl shadow-lg z-20 py-2 px-3">
                <div className="text-xs font-bold text-slate-400 mb-2 uppercase">Filter by Date</div>
                {/* Mock date filters - in a real app these would update state and filter the tickets array */}
                <button onClick={() => setActiveFilterDropdown(null)} className="w-full text-left py-1 text-sm text-slate-700 hover:text-brand-cyan">Today</button>
                <button onClick={() => setActiveFilterDropdown(null)} className="w-full text-left py-1 text-sm text-slate-700 hover:text-brand-cyan">Yesterday</button>
                <button onClick={() => setActiveFilterDropdown(null)} className="w-full text-left py-1 text-sm text-slate-700 hover:text-brand-cyan">This Week</button>
                <button onClick={() => setActiveFilterDropdown(null)} className="w-full text-left py-1 text-sm text-slate-700 hover:text-brand-cyan">Last 30 Days</button>
              </div>
            )}
          </div>

          {/* Sort Dropdown */}
          <div className="hidden xl:block relative filter-dropdown-container">
            <button onClick={() => setActiveFilterDropdown(activeFilterDropdown === 'sort' ? null : 'sort')} className="flex items-center gap-1.5 px-3 py-2.5 bg-white border border-slate-200 rounded-xl text-[13px] font-bold text-slate-700 hover:bg-slate-50 transition-colors shadow-sm">
              Sort <ArrowRightLeft className="w-3.5 h-3.5 text-slate-400 rotate-90" />
            </button>
            {activeFilterDropdown === 'sort' && (
              <div className="absolute top-full left-0 mt-1 w-48 bg-white border border-slate-200 rounded-xl shadow-lg z-20 py-1">
                {ALL_COLUMNS.filter(c => c !== "Action" && c !== "Counter / Agent" && c !== "Called At").map(col => (
                  <button key={col} onClick={() => { handleSort(col === "Token ID" ? "tokenId" : col === "Customer" ? "customerName" : col === "Service Type" ? "serviceType" : col === "Priority" ? "priority" : col === "Channel" ? "channel" : col === "Status" ? "status" : col === "Created" ? "createdAt" : "waitTimer"); setActiveFilterDropdown(null); }} className="w-full text-left px-4 py-2 text-sm text-slate-700 hover:bg-slate-50">
                    {col}
                  </button>
                ))}
              </div>
            )}
          </div>

        </div>`;

content = content.replace(target, replacement);
fs.writeFileSync('src/components/QueueTickets.tsx', content);
